import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Home, Ship, Users, Package, FileText, Settings, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { useAppData } from '../lib/AppDataContext';
import clsx from 'clsx';

const navItems = [
  { to: '/', icon: Home, label: 'Dashboard' },
  { to: '/vessels', icon: Ship, label: 'Vessels' },
  { to: '/crew', icon: Users, label: 'Crew' },
  { to: '/inventory', icon: Package, label: 'Inventory' },
  { to: '/incidents', icon: FileText, label: 'Incidents' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const { vessels, selectedVesselId } = useAppData();
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const selectedVessel = vessels.find((v) => v.id === selectedVesselId);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-dvh flex flex-col bg-navy-900 text-white">
      {/* Top bar */}
      <header className="safe-top sticky top-0 z-40 bg-navy-950/95 backdrop-blur border-b border-navy-700">
        <div className="flex items-center justify-between px-4 h-14">
          <button
            onClick={() => setMenuOpen(true)}
            className="p-2 -ml-2 rounded-lg hover:bg-navy-800 active:bg-navy-700"
            aria-label="Open menu"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex flex-col items-center">
            <span className="text-sm font-semibold tracking-wider text-turquoise-400">SENTINEL MARINE</span>
            {selectedVessel && (
              <span className="text-xs text-silver-400 truncate max-w-[180px]">{selectedVessel.name}</span>
            )}
          </div>
          <div className="w-10" /> {/* spacer */}
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto pb-20">
        <Outlet />
      </main>

      {/* Bottom nav - mobile first */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-navy-950/95 backdrop-blur border-t border-navy-700 safe-bottom">
        <div className="flex justify-around items-center h-16 max-w-lg mx-auto">
          {navItems.slice(0, 5).map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              className={({ isActive }) =>
                clsx(
                  'flex flex-col items-center justify-center w-16 h-full text-xs gap-0.5 transition-colors',
                  isActive ? 'text-turquoise-400' : 'text-silver-400 hover:text-silver-200'
                )
              }
            >
              <Icon className="w-5 h-5" strokeWidth={1.75} />
              <span>{label}</span>
            </NavLink>
          ))}
        </div>
      </nav>

      {/* Side drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMenuOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-72 max-w-[85vw] bg-navy-950 border-r border-navy-700 flex flex-col safe-top">
            <div className="flex items-center justify-between p-4 border-b border-navy-700">
              <div>
                <div className="text-turquoise-400 font-semibold tracking-wider text-sm">SENTINEL MARINE</div>
                <div className="text-xs text-silver-400 mt-0.5">{user?.fullName}</div>
              </div>
              <button onClick={() => setMenuOpen(false)} className="p-2 rounded-lg hover:bg-navy-800">
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1">
              {navItems.map(({ to, icon: Icon, label }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === '/'}
                  onClick={() => setMenuOpen(false)}
                  className={({ isActive }) =>
                    clsx(
                      'flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-colors',
                      isActive ? 'bg-navy-700 text-turquoise-400' : 'text-silver-200 hover:bg-navy-800'
                    )
                  }
                >
                  <Icon className="w-5 h-5" />
                  {label}
                </NavLink>
              ))}
            </nav>
            <div className="p-3 border-t border-navy-700">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 w-full px-3 py-3 rounded-xl text-sm text-silver-300 hover:bg-navy-800"
              >
                <LogOut className="w-5 h-5" />
                Sign out
              </button>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
