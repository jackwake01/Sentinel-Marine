import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './lib/AuthContext';
import { AppDataProvider } from './lib/AppDataContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Vessels from './pages/Vessels';
import Crew from './pages/Crew';
import Inventory from './pages/Inventory';
import Incidents from './pages/Incidents';
import NewIncident from './pages/NewIncident';
import IncidentDetail from './pages/IncidentDetail';
import Handover from './pages/Handover';
import Settings from './pages/Settings';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  if (isLoading) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-navy-950">
        <div className="text-turquoise-400 text-sm tracking-wider">SENTINEL MARINE</div>
      </div>
    );
  }
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="vessels" element={<Vessels />} />
        <Route path="crew" element={<Crew />} />
        <Route path="inventory" element={<Inventory />} />
        <Route path="incidents" element={<Incidents />} />
        <Route path="settings" element={<Settings />} />
      </Route>
      {/* Full-screen incident flows (no bottom nav) */}
      <Route
        path="incident/new"
        element={
          <ProtectedRoute>
            <NewIncident />
          </ProtectedRoute>
        }
      />
      <Route
        path="incident/:id"
        element={
          <ProtectedRoute>
            <IncidentDetail />
          </ProtectedRoute>
        }
      />
      <Route
        path="incident/:id/handover"
        element={
          <ProtectedRoute>
            <Handover />
          </ProtectedRoute>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppDataProvider>
        <AppRoutes />
      </AppDataProvider>
    </AuthProvider>
  );
}
