import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { Vessel, CrewMember, InventoryItem, MedicalIncident, TimelineEntry, Observation, MedicationAdmin } from '../types';
import { DEMO_VESSELS, DEMO_CREW, DEMO_INVENTORY, DEMO_INCIDENTS } from './mockData';
import { load, save } from './storage';

interface AppDataContextType {
  vessels: Vessel[];
  crew: CrewMember[];
  inventory: InventoryItem[];
  incidents: MedicalIncident[];
  selectedVesselId: string | null;
  setSelectedVesselId: (id: string | null) => void;
  addVessel: (v: Omit<Vessel, 'id' | 'createdAt'>) => void;
  updateVessel: (id: string, data: Partial<Vessel>) => void;
  getCrewForVessel: (vesselId: string) => CrewMember[];
  getInventoryForVessel: (vesselId: string) => InventoryItem[];
  getIncidentsForVessel: (vesselId: string) => MedicalIncident[];
  startIncident: (vesselId: string, patientId: string, patientName: string, location: string, createdBy: string) => MedicalIncident;
  updateIncident: (id: string, data: Partial<MedicalIncident>) => void;
  addObservation: (incidentId: string, obs: Omit<Observation, 'id' | 'incidentId'>) => void;
  addMedication: (incidentId: string, med: Omit<MedicationAdmin, 'id' | 'incidentId'>) => void;
  addTimelineEntry: (incidentId: string, entry: Omit<TimelineEntry, 'id' | 'incidentId'>) => void;
  closeIncident: (id: string) => void;
}

const AppDataContext = createContext<AppDataContextType | null>(null);

export function AppDataProvider({ children }: { children: ReactNode }) {
  const [vessels, setVessels] = useState<Vessel[]>(() => load('vessels', DEMO_VESSELS));
  const [crew, setCrew] = useState<CrewMember[]>(() => load('crew', DEMO_CREW));
  const [inventory, setInventory] = useState<InventoryItem[]>(() => load('inventory', DEMO_INVENTORY));
  const [incidents, setIncidents] = useState<MedicalIncident[]>(() => load('incidents', DEMO_INCIDENTS));
  const [selectedVesselId, setSelectedVesselId] = useState<string | null>(() => load('selectedVesselId', DEMO_VESSELS[0]?.id ?? null));

  useEffect(() => { save('vessels', vessels); }, [vessels]);
  useEffect(() => { save('crew', crew); }, [crew]);
  useEffect(() => { save('inventory', inventory); }, [inventory]);
  useEffect(() => { save('incidents', incidents); }, [incidents]);
  useEffect(() => { save('selectedVesselId', selectedVesselId); }, [selectedVesselId]);

  const addVessel = (v: Omit<Vessel, 'id' | 'createdAt'>) => {
    const newV: Vessel = { ...v, id: `ves-${Date.now()}`, createdAt: new Date().toISOString() };
    setVessels((prev) => [...prev, newV]);
  };

  const updateVessel = (id: string, data: Partial<Vessel>) => {
    setVessels((prev) => prev.map((v) => (v.id === id ? { ...v, ...data } : v)));
  };

  const getCrewForVessel = (vesselId: string) => crew.filter((c) => c.vesselId === vesselId);
  const getInventoryForVessel = (vesselId: string) => inventory.filter((i) => i.vesselId === vesselId);
  const getIncidentsForVessel = (vesselId: string) => incidents.filter((i) => i.vesselId === vesselId).sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());

  const startIncident = (vesselId: string, patientId: string, patientName: string, location: string, createdBy: string): MedicalIncident => {
    const now = new Date().toISOString();
    const id = `inc-${Date.now()}`;
    const timeline: TimelineEntry[] = [{
      id: `tl-${Date.now()}`,
      incidentId: id,
      timestamp: now,
      type: 'created',
      description: 'Incident created',
      recordedBy: createdBy,
    }];
    const incident: MedicalIncident = {
      id,
      vesselId,
      patientId,
      patientName,
      status: 'active',
      startTime: now,
      location,
      symptoms: [],
      treatments: [],
      createdBy,
      observations: [],
      medications: [],
      timeline,
    };
    setIncidents((prev) => [incident, ...prev]);
    return incident;
  };

  const updateIncident = (id: string, data: Partial<MedicalIncident>) => {
    setIncidents((prev) => prev.map((i) => (i.id === id ? { ...i, ...data } : i)));
  };

  const addObservation = (incidentId: string, obs: Omit<Observation, 'id' | 'incidentId'>) => {
    const full: Observation = { ...obs, id: `obs-${Date.now()}`, incidentId };
    setIncidents((prev) => prev.map((i) => {
      if (i.id !== incidentId) return i;
      const timelineEntry: TimelineEntry = {
        id: `tl-${Date.now()}`,
        incidentId,
        timestamp: obs.timestamp,
        type: 'observation',
        description: 'Patient observations recorded',
        recordedBy: obs.recordedBy,
      };
      return {
        ...i,
        observations: [...i.observations, full].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()),
        timeline: [...i.timeline, timelineEntry].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()),
      };
    }));
  };

  const addMedication = (incidentId: string, med: Omit<MedicationAdmin, 'id' | 'incidentId'>) => {
    const full: MedicationAdmin = { ...med, id: `med-${Date.now()}`, incidentId };
    setIncidents((prev) => prev.map((i) => {
      if (i.id !== incidentId) return i;
      const timelineEntry: TimelineEntry = {
        id: `tl-${Date.now()}`,
        incidentId,
        timestamp: med.timestamp,
        type: 'medication',
        description: `Medication administered: ${med.medicationName} ${med.dose}`,
        recordedBy: med.administeredBy,
      };
      return {
        ...i,
        medications: [...i.medications, full],
        timeline: [...i.timeline, timelineEntry].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()),
      };
    }));
  };

  const addTimelineEntry = (incidentId: string, entry: Omit<TimelineEntry, 'id' | 'incidentId'>) => {
    const full: TimelineEntry = { ...entry, id: `tl-${Date.now()}`, incidentId };
    setIncidents((prev) => prev.map((i) => {
      if (i.id !== incidentId) return i;
      return {
        ...i,
        timeline: [...i.timeline, full].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()),
      };
    }));
  };

  const closeIncident = (id: string) => {
    setIncidents((prev) => prev.map((i) => i.id === id ? { ...i, status: 'closed', endTime: new Date().toISOString() } : i));
  };

  return (
    <AppDataContext.Provider value={{
      vessels, crew, inventory, incidents, selectedVesselId, setSelectedVesselId,
      addVessel, updateVessel, getCrewForVessel, getInventoryForVessel, getIncidentsForVessel,
      startIncident, updateIncident, addObservation, addMedication, addTimelineEntry, closeIncident,
    }}>
      {children}
    </AppDataContext.Provider>
  );
}

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error('useAppData must be used within AppDataProvider');
  return ctx;
}
