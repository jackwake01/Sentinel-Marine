import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { User, AuthState } from '../types';
import { DEMO_USER } from './mockData';
import { load, save, remove } from './storage';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (email: string, password: string, fullName: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  demoLogin: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
  });

  useEffect(() => {
    const saved = load<User | null>('user', null);
    if (saved) {
      setState({ user: saved, isAuthenticated: true, isLoading: false });
    } else {
      setState((s) => ({ ...s, isLoading: false }));
    }
  }, []);

  const login = async (email: string, _password: string) => {
    // Demo: accept any password for known demo email, or create session
    await new Promise((r) => setTimeout(r, 400));
    if (email.toLowerCase() === DEMO_USER.email.toLowerCase() || email.includes('@')) {
      const user = { ...DEMO_USER, email };
      save('user', user);
      setState({ user, isAuthenticated: true, isLoading: false });
      return { success: true };
    }
    return { success: false, error: 'Invalid credentials. Use demo login or any email for prototype.' };
  };

  const register = async (email: string, _password: string, fullName: string) => {
    await new Promise((r) => setTimeout(r, 500));
    const user: User = {
      id: `user-${Date.now()}`,
      email,
      fullName,
      role: 'company_admin',
      companyId: 'comp-new',
      vesselIds: [],
      createdAt: new Date().toISOString(),
    };
    save('user', user);
    setState({ user, isAuthenticated: true, isLoading: false });
    return { success: true };
  };

  const logout = () => {
    remove('user');
    setState({ user: null, isAuthenticated: false, isLoading: false });
  };

  const demoLogin = () => {
    save('user', DEMO_USER);
    setState({ user: DEMO_USER, isAuthenticated: true, isLoading: false });
  };

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout, demoLogin }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
