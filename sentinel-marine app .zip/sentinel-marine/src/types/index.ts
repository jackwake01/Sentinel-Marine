export type UserRole = 'company_admin' | 'captain_medical_officer' | 'crew_member';

export interface User {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  companyId: string;
  vesselIds: string[];
  avatarUrl?: string;
  createdAt: string;
}

export interface Company {
  id: string;
  name: string;
  registrationNumber?: string;
  address?: string;
  contactEmail: string;
  contactPhone?: string;
  createdAt: string;
}

export interface Vessel {
  id: string;
  companyId: string;
  name: string;
  type: string;
  registrationNumber: string;
  flagState: string;
  lengthMeters: number;
  maxPersons: number;
  homePort: string;
  captainName: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  createdAt: string;
}

export interface CrewMember {
  id: string;
  vesselId: string;
  userId?: string;
  fullName: string;
  dateOfBirth: string;
  nationality: string;
  position: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  // Medical
  allergies: string[];
  currentMedications: string[];
  medicalConditions: string[];
  medicalHistory: string;
  bloodGroup?: string;
  additionalNotes?: string;
  consentGiven: boolean;
  consentDate?: string;
  lastUpdated: string;
}

export interface InventoryItem {
  id: string;
  vesselId: string;
  name: string;
  category: string;
  quantity: number;
  minQuantity: number;
  expiryDate?: string;
  storageLocation: string;
  lastInspectionDate?: string;
  notes?: string;
  status: 'green' | 'amber' | 'red';
}

export interface Observation {
  id: string;
  incidentId: string;
  timestamp: string;
  heartRate?: number;
  systolicBP?: number;
  diastolicBP?: number;
  respiratoryRate?: number;
  oxygenSaturation?: number;
  temperature?: number;
  gcs?: number;
  bloodGlucose?: number;
  painScore?: number;
  consciousness?: string;
  notes?: string;
  recordedBy: string;
}

export interface MedicationAdmin {
  id: string;
  incidentId: string;
  timestamp: string;
  medicationName: string;
  dose: string;
  route: string;
  administeredBy: string;
  reason: string;
  notes?: string;
  inventoryItemId?: string;
}

export interface TimelineEntry {
  id: string;
  incidentId: string;
  timestamp: string;
  type: 'created' | 'assessment' | 'observation' | 'treatment' | 'medication' | 'note' | 'handover' | 'correction';
  description: string;
  recordedBy: string;
  originalValue?: string; // for audit trail on corrections
}

export interface MedicalIncident {
  id: string;
  vesselId: string;
  patientId: string;
  patientName: string;
  status: 'active' | 'closed' | 'handed_over';
  startTime: string;
  endTime?: string;
  location: string;
  mechanismOfInjury?: string;
  natureOfIllness?: string;
  initialCondition?: string;
  symptoms: string[];
  treatments: string[];
  additionalNotes?: string;
  createdBy: string;
  observations: Observation[];
  medications: MedicationAdmin[];
  timeline: TimelineEntry[];
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}
