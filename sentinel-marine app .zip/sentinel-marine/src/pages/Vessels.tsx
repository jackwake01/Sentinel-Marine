import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Ship, Plus, ChevronRight, X } from 'lucide-react';
import { useAppData } from '../lib/AppDataContext';
import { useAuth } from '../lib/AuthContext';
import type { Vessel } from '../types';

export default function Vessels() {
  const { vessels, selectedVesselId, setSelectedVesselId, addVessel } = useAppData();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: '',
    type: 'Motor Yacht',
    registrationNumber: '',
    flagState: '',
    lengthMeters: '',
    maxPersons: '',
    homePort: '',
    captainName: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addVessel({
      companyId: user?.companyId || 'comp-001',
      name: form.name,
      type: form.type,
      registrationNumber: form.registrationNumber,
      flagState: form.flagState,
      lengthMeters: parseFloat(form.lengthMeters) || 0,
      maxPersons: parseInt(form.maxPersons) || 0,
      homePort: form.homePort,
      captainName: form.captainName,
      emergencyContactName: form.emergencyContactName,
      emergencyContactPhone: form.emergencyContactPhone,
    });
    setShowForm(false);
    setForm({
      name: '', type: 'Motor Yacht', registrationNumber: '', flagState: '',
      lengthMeters: '', maxPersons: '', homePort: '', captainName: '',
      emergencyContactName: '', emergencyContactPhone: '',
    });
  };

  return (
    <div className="px-4 pt-4 pb-6 max-w-lg mx-auto">
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl font-semibold text-white">Vessels</h1>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-turquoise-500 text-navy-950 text-sm font-semibold"
        >
          <Plus className="w-4 h-4" />
          Add
        </button>
      </div>

      <div className="space-y-3">
        {vessels.map((v) => (
          <button
            key={v.id}
            onClick={() => {
              setSelectedVesselId(v.id);
              navigate('/');
            }}
            className={`w-full flex items-center gap-4 p-4 rounded-xl border text-left transition-colors ${
              v.id === selectedVesselId
                ? 'bg-turquoise-500/10 border-turquoise-500/50'
                : 'bg-navy-800 border-navy-700 hover:border-navy-600'
            }`}
          >
            <div className="w-12 h-12 rounded-xl bg-navy-700 flex items-center justify-center shrink-0">
              <Ship className="w-6 h-6 text-turquoise-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-white truncate">{v.name}</div>
              <div className="text-xs text-silver-400 mt-0.5">
                {v.type} · {v.lengthMeters}m · {v.flagState}
              </div>
              <div className="text-xs text-silver-500 mt-0.5">
                {v.registrationNumber} · {v.homePort}
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-silver-500 shrink-0" />
          </button>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowForm(false)} />
          <div className="relative w-full max-w-lg max-h-[90dvh] overflow-y-auto bg-navy-900 border border-navy-700 rounded-t-2xl sm:rounded-2xl p-5">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-semibold">Register vessel</h2>
              <button onClick={() => setShowForm(false)} className="p-2 rounded-lg hover:bg-navy-800">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-3">
              {[
                { key: 'name', label: 'Vessel name', placeholder: 'M/Y Aurora' },
                { key: 'type', label: 'Type', placeholder: 'Motor Yacht' },
                { key: 'registrationNumber', label: 'Registration number', placeholder: 'GB-MY-88421' },
                { key: 'flagState', label: 'Flag state', placeholder: 'United Kingdom' },
                { key: 'lengthMeters', label: 'Length (metres)', placeholder: '52.4', type: 'number' },
                { key: 'maxPersons', label: 'Max persons onboard', placeholder: '18', type: 'number' },
                { key: 'homePort', label: 'Home port', placeholder: 'Antibes' },
                { key: 'captainName', label: "Captain's name", placeholder: 'James Harrington' },
                { key: 'emergencyContactName', label: 'Emergency contact name', placeholder: 'Shore Ops' },
                { key: 'emergencyContactPhone', label: 'Emergency contact phone', placeholder: '+33 4 93 00 00 00' },
              ].map(({ key, label, placeholder, type }) => (
                <div key={key}>
                  <label className="block text-xs text-silver-400 mb-1">{label}</label>
                  <input
                    type={type || 'text'}
                    required
                    value={(form as any)[key]}
                    onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                    placeholder={placeholder}
                    className="w-full px-3 py-2.5 rounded-xl bg-navy-800 border border-navy-600 text-white text-sm placeholder:text-silver-500 focus:outline-none focus:border-turquoise-500"
                  />
                </div>
              ))}
              <button
                type="submit"
                className="w-full mt-2 py-3.5 rounded-xl bg-turquoise-500 text-navy-950 font-semibold"
              >
                Register vessel
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
