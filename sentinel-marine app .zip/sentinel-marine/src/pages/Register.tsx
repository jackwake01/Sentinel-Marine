import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext';
import { Shield } from 'lucide-react';

export default function Register() {
  const { register, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (isAuthenticated) {
    navigate('/');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    const result = await register(email, password, fullName);
    setLoading(false);
    if (result.success) {
      navigate('/');
    } else {
      setError(result.error || 'Registration failed');
    }
  };

  return (
    <div className="min-h-dvh flex flex-col bg-navy-950 safe-top safe-bottom">
      <div className="flex-1 flex flex-col items-center justify-center px-6 pt-10 pb-6">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-navy-700 to-navy-800 border border-turquoise-500/30 flex items-center justify-center mb-5">
          <Shield className="w-8 h-8 text-turquoise-400" strokeWidth={1.5} />
        </div>
        <h1 className="text-xl font-bold tracking-[0.15em] text-white mb-1">SENTINEL MARINE</h1>
        <p className="text-silver-400 text-sm">Create your account</p>
      </div>

      <div className="px-5 pb-8">
        <div className="bg-navy-900 border border-navy-700 rounded-2xl p-6 shadow-xl max-w-md mx-auto">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-silver-400 mb-1.5">Full name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="James Harrington"
                required
                className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white placeholder:text-silver-500 focus:outline-none focus:border-turquoise-500 focus:ring-1 focus:ring-turquoise-500/50"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-silver-400 mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                required
                className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white placeholder:text-silver-500 focus:outline-none focus:border-turquoise-500 focus:ring-1 focus:ring-turquoise-500/50"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-silver-400 mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min. 6 characters"
                required
                className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white placeholder:text-silver-500 focus:outline-none focus:border-turquoise-500 focus:ring-1 focus:ring-turquoise-500/50"
              />
            </div>

            {error && (
              <p className="text-sm text-status-red bg-status-red/10 border border-status-red/20 rounded-lg px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-turquoise-500 hover:bg-turquoise-400 active:bg-turquoise-600 text-navy-950 font-semibold text-sm tracking-wide transition-colors disabled:opacity-60"
            >
              {loading ? 'Creating account…' : 'Create account'}
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-silver-500">
            Already have an account?{' '}
            <Link to="/login" className="text-turquoise-400 hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
