import { User, ChevronRight } from 'lucide-react';
import { useAppData } from '../lib/AppDataContext';
import { useNavigate } from 'react-router-dom';

export default function Crew() {
  const { selectedVesselId, vessels, getCrewForVessel } = useAppData();
  const navigate = useNavigate();
  const vessel = vessels.find((v) => v.id === selectedVesselId) ?? vessels[0];
  const crew = vessel ? getCrewForVessel(vessel.id) : [];

  return (
    <div className="px-4 pt-4 pb-6 max-w-lg mx-auto">
      <h1 className="text-xl font-semibold text-white mb-1">Crew Medical Profiles</h1>
      <p className="text-sm text-silver-400 mb-5">{vessel?.name || 'No vessel selected'}</p>

      <div className="space-y-2">
        {crew.map((c) => (
          <div
            key={c.id}
            className="flex items-center gap-3 p-4 rounded-xl bg-navy-800 border border-navy-700"
          >
            <div className="w-11 h-11 rounded-full bg-navy-700 flex items-center justify-center shrink-0">
              <User className="w-5 h-5 text-turquoise-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-white">{c.fullName}</div>
              <div className="text-xs text-silver-400">{c.position} · {c.nationality}</div>
              {c.allergies.length > 0 && (
                <div className="text-xs text-status-amber mt-0.5">Allergies: {c.allergies.join(', ')}</div>
              )}
            </div>
            <div className="text-xs text-silver-500">
              {c.bloodGroup || '—'}
            </div>
          </div>
        ))}
      </div>

      {crew.length === 0 && (
        <p className="text-silver-500 text-sm py-8 text-center">No crew registered for this vessel</p>
      )}
    </div>
  );
}
