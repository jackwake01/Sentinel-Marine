import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, ChevronLeft, User } from 'lucide-react';
import { useAppData } from '../lib/AppDataContext';
import { useAuth } from '../lib/AuthContext';

export default function NewIncident() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { selectedVesselId, vessels, getCrewForVessel, startIncident } = useAppData();
  const vessel = vessels.find((v) => v.id === selectedVesselId) ?? vessels[0];
  const crew = vessel ? getCrewForVessel(vessel.id) : [];

  const [step, setStep] = useState<'patient' | 'details'>('patient');
  const [patientId, setPatientId] = useState('');
  const [location, setLocation] = useState('Onboard');
  const [mechanism, setMechanism] = useState('');
  const [nature, setNature] = useState('');
  const [condition, setCondition] = useState('');

  if (!vessel) {
    return (
      <div className="p-6 text-center">
        <p className="text-silver-400">Select a vessel first</p>
        <button onClick={() => navigate('/vessels')} className="mt-4 text-turquoise-400">
          Go to vessels
        </button>
      </div>
    );
  }

  const selectedPatient = crew.find((c) => c.id === patientId);

  const handleStart = () => {
    if (!selectedPatient || !user) return;
    const incident = startIncident(
      vessel.id,
      selectedPatient.id,
      selectedPatient.fullName,
      location,
      user.fullName
    );
    // Optionally attach initial details
    if (mechanism || nature || condition) {
      // update via the context after creation - for simplicity we navigate and let user fill
    }
    navigate(`/incident/${incident.id}`, { state: { mechanism, nature, condition } });
  };

  return (
    <div className="min-h-dvh bg-navy-900 flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-navy-950 border-b border-navy-700 px-4 py-3 flex items-center gap-3">
        <button onClick={() => (step === 'details' ? setStep('patient') : navigate(-1))} className="p-2 -ml-2 rounded-lg hover:bg-navy-800">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div>
          <div className="text-sm font-semibold text-white">Start Medical Incident</div>
          <div className="text-xs text-silver-400">{vessel.name}</div>
        </div>
      </div>

      <div className="flex-1 px-4 py-5 max-w-lg mx-auto w-full">
        {step === 'patient' && (
          <>
            <div className="flex items-center gap-3 mb-5 p-3 rounded-xl bg-status-red/10 border border-status-red/30">
              <AlertTriangle className="w-5 h-5 text-status-red shrink-0" />
              <p className="text-sm text-silver-200">Select the affected person to begin documentation. Time will be recorded automatically.</p>
            </div>

            <h2 className="text-sm font-semibold text-silver-400 mb-3 uppercase tracking-wider">Select patient</h2>
            <div className="space-y-2">
              {crew.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setPatientId(c.id);
                    setStep('details');
                  }}
                  className="w-full flex items-center gap-3 p-4 rounded-xl bg-navy-800 border border-navy-700 hover:border-turquoise-500/50 text-left transition-colors"
                >
                  <div className="w-11 h-11 rounded-full bg-navy-700 flex items-center justify-center shrink-0">
                    <User className="w-5 h-5 text-turquoise-400" />
                  </div>
                  <div>
                    <div className="font-medium text-white">{c.fullName}</div>
                    <div className="text-xs text-silver-400">{c.position}</div>
                    {c.allergies.length > 0 && (
                      <div className="text-xs text-status-amber mt-0.5">
                        Allergies: {c.allergies.join(', ')}
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </>
        )}

        {step === 'details' && selectedPatient && (
          <>
            <div className="mb-5 p-4 rounded-xl bg-navy-800 border border-navy-700">
              <div className="text-xs text-silver-500">Patient</div>
              <div className="font-semibold text-white">{selectedPatient.fullName}</div>
              <div className="text-sm text-silver-400">{selectedPatient.position}</div>
              {selectedPatient.allergies.length > 0 && (
                <div className="mt-2 text-sm text-status-amber font-medium">
                  ⚠ Allergies: {selectedPatient.allergies.join(', ')}
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs text-silver-400 mb-1.5">Incident location</label>
                <input
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white focus:outline-none focus:border-turquoise-500"
                  placeholder="e.g. Main deck, Galley, Engine room"
                />
              </div>
              <div>
                <label className="block text-xs text-silver-400 mb-1.5">Mechanism of injury (optional)</label>
                <input
                  value={mechanism}
                  onChange={(e) => setMechanism(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white focus:outline-none focus:border-turquoise-500"
                  placeholder="e.g. Fall from height, Crush injury"
                />
              </div>
              <div>
                <label className="block text-xs text-silver-400 mb-1.5">Nature of illness (optional)</label>
                <input
                  value={nature}
                  onChange={(e) => setNature(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white focus:outline-none focus:border-turquoise-500"
                  placeholder="e.g. Chest pain, Allergic reaction"
                />
              </div>
              <div>
                <label className="block text-xs text-silver-400 mb-1.5">Initial condition (optional)</label>
                <textarea
                  value={condition}
                  onChange={(e) => setCondition(e.target.value)}
                  rows={2}
                  className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white focus:outline-none focus:border-turquoise-500 resize-none"
                  placeholder="Brief description of patient on first assessment"
                />
              </div>
            </div>

            <button
              onClick={handleStart}
              className="w-full mt-6 py-4 rounded-xl bg-status-red hover:bg-red-600 text-white font-bold text-base tracking-wide shadow-lg shadow-red-900/30 active:scale-[0.98] transition-transform"
            >
              START INCIDENT NOW
            </button>
            <p className="text-center text-xs text-silver-500 mt-3">
              Incident time will be recorded as {new Date().toLocaleTimeString()}
            </p>
          </>
        )}
      </div>
    </div>
  );
}
