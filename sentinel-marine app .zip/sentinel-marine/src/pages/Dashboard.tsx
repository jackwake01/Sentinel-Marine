import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Package, Users, Clock, ChevronRight, Activity } from 'lucide-react';
import { useAppData } from '../lib/AppDataContext';
import { useAuth } from '../lib/AuthContext';
import { format } from 'date-fns';
import clsx from 'clsx';

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const {
    vessels,
    selectedVesselId,
    setSelectedVesselId,
    getCrewForVessel,
    getInventoryForVessel,
    getIncidentsForVessel,
  } = useAppData();

  const vessel = vessels.find((v) => v.id === selectedVesselId) ?? vessels[0];
  if (!vessel) {
    return (
      <div className="p-6 text-center">
        <p className="text-silver-400 mb-4">No vessels registered</p>
        <button
          onClick={() => navigate('/vessels')}
          className="px-5 py-3 rounded-xl bg-turquoise-500 text-navy-950 font-semibold"
        >
          Add a vessel
        </button>
      </div>
    );
  }

  const crew = getCrewForVessel(vessel.id);
  const inventory = getInventoryForVessel(vessel.id);
  const incidents = getIncidentsForVessel(vessel.id);
  const activeIncidents = incidents.filter((i) => i.status === 'active');
  const recentIncidents = incidents.slice(0, 3);

  const redItems = inventory.filter((i) => i.status === 'red').length;
  const amberItems = inventory.filter((i) => i.status === 'amber').length;
  const expiringSoon = inventory.filter((i) => {
    if (!i.expiryDate) return false;
    const days = (new Date(i.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return days > 0 && days <= 60;
  }).length;

  return (
    <div className="px-4 pt-4 pb-6 space-y-5 max-w-lg mx-auto">
      {/* Greeting */}
      <div>
        <p className="text-silver-400 text-sm">Welcome back</p>
        <h1 className="text-xl font-semibold text-white">{user?.fullName?.split(' ')[0] || 'Captain'}</h1>
      </div>

      {/* Vessel selector */}
      {vessels.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
          {vessels.map((v) => (
            <button
              key={v.id}
              onClick={() => setSelectedVesselId(v.id)}
              className={clsx(
                'shrink-0 px-4 py-2 rounded-full text-sm font-medium border transition-colors',
                v.id === vessel.id
                  ? 'bg-turquoise-500/15 border-turquoise-500 text-turquoise-400'
                  : 'bg-navy-800 border-navy-600 text-silver-300'
              )}
            >
              {v.name}
            </button>
          ))}
        </div>
      )}

      {/* START MEDICAL INCIDENT - primary CTA */}
      <button
        onClick={() => navigate('/incident/new')}
        className="w-full relative overflow-hidden rounded-2xl bg-gradient-to-br from-status-red to-red-700 p-5 text-left shadow-lg shadow-red-900/40 active:scale-[0.98] transition-transform"
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(255,255,255,0.12),transparent_50%)]" />
        <div className="relative flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-8 h-8 text-white" strokeWidth={2} />
          </div>
          <div>
            <div className="text-lg font-bold text-white tracking-wide">START MEDICAL INCIDENT</div>
            <div className="text-sm text-white/80 mt-0.5">One-tap incident documentation</div>
          </div>
        </div>
      </button>

      {/* Active incident banner */}
      {activeIncidents.length > 0 && (
        <button
          onClick={() => navigate(`/incident/${activeIncidents[0].id}`)}
          className="w-full flex items-center gap-3 p-4 rounded-xl bg-status-amber/15 border border-status-amber/40 text-left"
        >
          <Activity className="w-5 h-5 text-status-amber shrink-0 animate-pulse" />
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-status-amber">Active incident in progress</div>
            <div className="text-xs text-silver-300 truncate">
              {activeIncidents[0].patientName} · started {format(new Date(activeIncidents[0].startTime), 'HH:mm')}
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-status-amber" />
        </button>
      )}

      {/* Status cards */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => navigate('/crew')}
          className="bg-navy-800 border border-navy-700 rounded-xl p-4 text-left hover:border-navy-600 transition-colors"
        >
          <Users className="w-5 h-5 text-turquoise-400 mb-2" />
          <div className="text-2xl font-bold text-white">{crew.length}</div>
          <div className="text-xs text-silver-400">Crew onboard</div>
        </button>
        <button
          onClick={() => navigate('/inventory')}
          className="bg-navy-800 border border-navy-700 rounded-xl p-4 text-left hover:border-navy-600 transition-colors"
        >
          <Package className="w-5 h-5 text-turquoise-400 mb-2" />
          <div className="text-2xl font-bold text-white">{inventory.length}</div>
          <div className="text-xs text-silver-400">Inventory items</div>
        </button>
      </div>

      {/* Inventory alerts */}
      {(redItems > 0 || amberItems > 0 || expiringSoon > 0) && (
        <div className="bg-navy-800 border border-navy-700 rounded-xl p-4">
          <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <Package className="w-4 h-4 text-turquoise-400" />
            Inventory status
          </h3>
          <div className="space-y-2">
            {redItems > 0 && (
              <div className="flex items-center gap-2 text-sm">
                <span className="w-2.5 h-2.5 rounded-full bg-status-red" />
                <span className="text-status-red font-medium">{redItems} action required</span>
              </div>
            )}
            {amberItems > 0 && (
              <div className="flex items-center gap-2 text-sm">
                <span className="w-2.5 h-2.5 rounded-full bg-status-amber" />
                <span className="text-status-amber font-medium">{amberItems} attention required</span>
              </div>
            )}
            {expiringSoon > 0 && (
              <div className="flex items-center gap-2 text-sm">
                <Clock className="w-3.5 h-3.5 text-silver-400" />
                <span className="text-silver-300">{expiringSoon} expiring within 60 days</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Recent incidents */}
      <div className="bg-navy-800 border border-navy-700 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white">Recent incidents</h3>
          <button onClick={() => navigate('/incidents')} className="text-xs text-turquoise-400">
            View all
          </button>
        </div>
        {recentIncidents.length === 0 ? (
          <p className="text-sm text-silver-500 py-2">No incidents recorded</p>
        ) : (
          <div className="space-y-2">
            {recentIncidents.map((inc) => (
              <button
                key={inc.id}
                onClick={() => navigate(`/incident/${inc.id}`)}
                className="w-full flex items-center gap-3 p-3 rounded-lg bg-navy-900/60 hover:bg-navy-900 text-left"
              >
                <div
                  className={clsx(
                    'w-2 h-2 rounded-full shrink-0',
                    inc.status === 'active' ? 'bg-status-amber animate-pulse' : 'bg-silver-500'
                  )}
                />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white truncate">{inc.patientName}</div>
                  <div className="text-xs text-silver-400">
                    {format(new Date(inc.startTime), 'dd MMM yyyy · HH:mm')}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-silver-500" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Vessel quick info */}
      <div className="bg-navy-800 border border-navy-700 rounded-xl p-4 text-sm">
        <div className="text-xs text-silver-500 mb-1">Current vessel</div>
        <div className="font-semibold text-white">{vessel.name}</div>
        <div className="text-silver-400 mt-1">
          {vessel.type} · {vessel.lengthMeters}m · {vessel.flagState}
        </div>
        <div className="text-silver-500 text-xs mt-1">
          Capt. {vessel.captainName} · {vessel.homePort}
        </div>
      </div>
    </div>
  );
}
