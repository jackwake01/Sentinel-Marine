import { useAuth } from '../lib/AuthContext';
import { useNavigate } from 'react-router-dom';
import { LogOut, Shield, Info } from 'lucide-react';

export default function Settings() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="px-4 pt-4 pb-6 max-w-lg mx-auto">
      <h1 className="text-xl font-semibold text-white mb-5">Settings</h1>

      <div className="bg-navy-800 border border-navy-700 rounded-xl p-4 mb-4">
        <div className="text-xs text-silver-500 mb-1">Signed in as</div>
        <div className="font-medium text-white">{user?.fullName}</div>
        <div className="text-sm text-silver-400">{user?.email}</div>
        <div className="text-xs text-turquoise-400 mt-1 capitalize">
          {user?.role?.replace(/_/g, ' ')}
        </div>
      </div>

      <div className="bg-navy-800 border border-navy-700 rounded-xl p-4 mb-4 space-y-3">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-turquoise-400 shrink-0 mt-0.5" />
          <div>
            <div className="text-sm font-medium text-white">Prototype notice</div>
            <p className="text-xs text-silver-400 mt-1 leading-relaxed">
              This is a functional Phase 1 prototype of Sentinel Marine. Authentication uses local storage.
              Data is fictional demonstration data only. Not for clinical or operational use.
            </p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-turquoise-400 shrink-0 mt-0.5" />
          <div>
            <div className="text-sm font-medium text-white">Roadmap</div>
            <p className="text-xs text-silver-400 mt-1 leading-relaxed">
              Phase 1: Foundation ✓ · Phase 2–5: Medical profiles, inventory, incidents, handover (in progress) ·
              Phase 6: Offline, Stripe subscriptions, production security.
            </p>
          </div>
        </div>
      </div>

      <div className="text-xs text-silver-500 mb-4 space-y-1">
        <p>Subscription model: AUD $79 / vessel / month (not activated)</p>
        <p>Version 0.1.0 · React + TypeScript · Local persistence</p>
      </div>

      <button
        onClick={handleLogout}
        className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl border border-navy-600 text-silver-300 hover:bg-navy-800"
      >
        <LogOut className="w-4 h-4" />
        Sign out
      </button>
    </div>
  );
}
