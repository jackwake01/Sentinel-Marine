import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, Download, Printer } from 'lucide-react';
import { useAppData } from '../lib/AppDataContext';
import { format } from 'date-fns';

export default function Handover() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { incidents, crew, vessels } = useAppData();

  const incident = incidents.find((i) => i.id === id);
  const patient = crew.find((c) => c.id === incident?.patientId);
  const vessel = vessels.find((v) => v.id === incident?.vesselId);

  if (!incident || !patient || !vessel) {
    return (
      <div className="p-6 text-center">
        <p className="text-silver-400">Incident data incomplete</p>
        <button onClick={() => navigate(-1)} className="mt-4 text-turquoise-400">Go back</button>
      </div>
    );
  }

  const latestObs = incident.observations.length > 0
    ? incident.observations[incident.observations.length - 1]
    : null;

  const missing: string[] = [];
  if (!incident.mechanismOfInjury && !incident.natureOfIllness) missing.push('Mechanism / Medical complaint');
  if (incident.observations.length === 0) missing.push('Vital signs / observations');
  if (!patient.bloodGroup) missing.push('Blood group');

  const handlePrint = () => {
    window.print();
  };

  const Section = ({ letter, title, children }: { letter: string; title: string; children: React.ReactNode }) => (
    <div className="mb-5 break-inside-avoid">
      <div className="flex items-center gap-2 mb-2">
        <span className="w-7 h-7 rounded-lg bg-navy-700 text-turquoise-400 font-bold text-sm flex items-center justify-center">
          {letter}
        </span>
        <h3 className="text-sm font-semibold text-white uppercase tracking-wide">{title}</h3>
      </div>
      <div className="pl-9 text-sm text-silver-200 space-y-1">{children}</div>
    </div>
  );

  return (
    <div className="min-h-dvh bg-navy-900">
      {/* App chrome - hidden on print */}
      <div className="print:hidden sticky top-0 z-10 bg-navy-950 border-b border-navy-700 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 rounded-lg hover:bg-navy-800">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <div className="text-sm font-semibold text-white">Medical Handover</div>
          <div className="text-xs text-silver-400">IMIST-AMBO structure</div>
        </div>
        <button onClick={handlePrint} className="p-2 rounded-lg hover:bg-navy-800" title="Print / Save PDF">
          <Printer className="w-5 h-5 text-turquoise-400" />
        </button>
      </div>

      <div className="px-4 py-5 max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6 pb-5 border-b border-navy-700">
          <div className="text-turquoise-400 font-bold tracking-[0.2em] text-sm">SENTINEL MARINE</div>
          <div className="text-white text-lg font-semibold mt-1">Medical Handover Report</div>
          <div className="text-xs text-silver-500 mt-1">
            Generated {format(new Date(), 'dd MMM yyyy · HH:mm')} · Incident started {format(new Date(incident.startTime), 'dd MMM yyyy · HH:mm')}
          </div>
        </div>

        {missing.length > 0 && (
          <div className="mb-5 p-3 rounded-xl bg-status-amber/10 border border-status-amber/30 text-sm text-status-amber print:border-amber-600">
            <strong>Incomplete information:</strong> {missing.join('; ')}. Fields marked “Not recorded” were not documented during this incident.
          </div>
        )}

        <Section letter="I" title="Identification">
          <p><strong>Patient:</strong> {patient.fullName}</p>
          <p><strong>DOB:</strong> {patient.dateOfBirth} · <strong>Nationality:</strong> {patient.nationality}</p>
          <p><strong>Position:</strong> {patient.position}</p>
          <p><strong>Blood group:</strong> {patient.bloodGroup || 'Not recorded'}</p>
          <p><strong>Vessel:</strong> {vessel.name} ({vessel.type}) · {vessel.registrationNumber}</p>
          <p><strong>Flag:</strong> {vessel.flagState} · <strong>Location of incident:</strong> {incident.location}</p>
          <p><strong>Captain:</strong> {vessel.captainName}</p>
          <p><strong>Emergency contact:</strong> {patient.emergencyContactName} — {patient.emergencyContactPhone}</p>
        </Section>

        <Section letter="M" title="Mechanism / Medical complaint">
          <p><strong>Mechanism of injury:</strong> {incident.mechanismOfInjury || 'Not recorded'}</p>
          <p><strong>Nature of illness:</strong> {incident.natureOfIllness || 'Not recorded'}</p>
          <p><strong>Initial condition:</strong> {incident.initialCondition || 'Not recorded'}</p>
        </Section>

        <Section letter="I" title="Injuries / Information">
          <p><strong>Symptoms:</strong> {incident.symptoms.length > 0 ? incident.symptoms.join(', ') : 'Not specifically listed'}</p>
          <p><strong>Additional notes:</strong> {incident.additionalNotes || 'None'}</p>
        </Section>

        <Section letter="S" title="Signs">
          {latestObs ? (
            <>
              <p className="text-xs text-silver-500 mb-1">Latest observations — {format(new Date(latestObs.timestamp), 'HH:mm:ss')}</p>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                {latestObs.heartRate != null && <p>HR: {latestObs.heartRate} bpm</p>}
                {latestObs.systolicBP != null && <p>BP: {latestObs.systolicBP}/{latestObs.diastolicBP} mmHg</p>}
                {latestObs.respiratoryRate != null && <p>RR: {latestObs.respiratoryRate} /min</p>}
                {latestObs.oxygenSaturation != null && <p>SpO₂: {latestObs.oxygenSaturation}%</p>}
                {latestObs.temperature != null && <p>Temp: {latestObs.temperature} °C</p>}
                {latestObs.gcs != null && <p>GCS: {latestObs.gcs}</p>}
                {latestObs.painScore != null && <p>Pain: {latestObs.painScore}/10</p>}
                {latestObs.bloodGlucose != null && <p>BGL: {latestObs.bloodGlucose}</p>}
                {latestObs.consciousness && <p>Consciousness: {latestObs.consciousness}</p>}
              </div>
              {incident.observations.length > 1 && (
                <p className="text-xs text-silver-500 mt-2">{incident.observations.length} observation sets recorded — see timeline</p>
              )}
            </>
          ) : (
            <p className="text-status-amber">No vital signs recorded</p>
          )}
        </Section>

        <Section letter="T" title="Treatment">
          {incident.treatments.length > 0 ? (
            <ul className="list-disc pl-4">{incident.treatments.map((t, i) => <li key={i}>{t}</li>)}</ul>
          ) : (
            <p>No structured treatments listed</p>
          )}
          {incident.medications.length > 0 && (
            <div className="mt-2">
              <p className="font-medium mb-1">Medications administered:</p>
              <ul className="list-disc pl-4">
                {incident.medications.map((m) => (
                  <li key={m.id}>
                    {format(new Date(m.timestamp), 'HH:mm')} — {m.medicationName} {m.dose} ({m.route}) by {m.administeredBy}
                    {m.reason ? ` — ${m.reason}` : ''}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Section>

        <Section letter="A" title="Allergies">
          <p className={patient.allergies.length > 0 ? 'text-status-amber font-medium' : ''}>
            {patient.allergies.length > 0 ? patient.allergies.join(', ') : 'None known'}
          </p>
        </Section>

        <Section letter="M" title="Medications (regular)">
          <p>{patient.currentMedications.length > 0 ? patient.currentMedications.join(', ') : 'None recorded'}</p>
        </Section>

        <Section letter="B" title="Background">
          <p><strong>Conditions:</strong> {patient.medicalConditions.join(', ') || 'None recorded'}</p>
          <p><strong>History:</strong> {patient.medicalHistory || 'None recorded'}</p>
        </Section>

        <Section letter="O" title="Other relevant information">
          <p><strong>Vessel emergency contact:</strong> {vessel.emergencyContactName} — {vessel.emergencyContactPhone}</p>
          <p><strong>Incident status:</strong> {incident.status}</p>
          <p><strong>Documented by:</strong> {incident.createdBy}</p>
        </Section>

        {/* Timeline */}
        <div className="mt-6 pt-5 border-t border-navy-700">
          <h3 className="text-sm font-semibold text-white uppercase tracking-wide mb-3">Chronological Timeline</h3>
          <div className="space-y-2 text-sm">
            {incident.timeline.map((entry) => (
              <div key={entry.id} className="flex gap-3">
                <span className="font-mono text-xs text-turquoise-400 shrink-0 w-16">
                  {format(new Date(entry.timestamp), 'HH:mm:ss')}
                </span>
                <span className="text-silver-200">{entry.description}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-navy-700 text-center text-[10px] text-silver-600">
          Generated by SENTINEL MARINE · Marine Medical Management · Fictional demonstration data · Not for clinical use
        </div>
      </div>

      {/* Print styles */}
      <style>{`
        @media print {
          body { background: white !important; color: black !important; }
          .print\\:hidden { display: none !important; }
          * { color: black !important; border-color: #ccc !important; }
          .text-turquoise-400, .text-status-amber { color: #000 !important; }
        }
      `}</style>
    </div>
  );
}
