import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext';
import { Anchor, Shield } from 'lucide-react';

export default function Login() {
  const { login, demoLogin, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (isAuthenticated) {
    navigate('/');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const result = await login(email, password);
    setLoading(false);
    if (result.success) {
      navigate('/');
    } else {
      setError(result.error || 'Login failed');
    }
  };

  const handleDemo = () => {
    demoLogin();
    navigate('/');
  };

  return (
    <div className="min-h-dvh flex flex-col bg-navy-950 safe-top safe-bottom">
      {/* Splash branding */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pt-12 pb-8">
        <div className="relative mb-8">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-navy-700 to-navy-800 border border-turquoise-500/30 flex items-center justify-center shadow-lg shadow-turquoise-500/10">
            <Shield className="w-10 h-10 text-turquoise-400" strokeWidth={1.5} />
          </div>
          <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-navy-800 border border-turquoise-500/40 flex items-center justify-center">
            <Anchor className="w-3.5 h-3.5 text-turquoise-400" />
          </div>
        </div>
        <h1 className="text-2xl font-bold tracking-[0.2em] text-white mb-1">SENTINEL MARINE</h1>
        <p className="text-silver-400 text-sm tracking-wide">Marine Medical Management</p>
      </div>

      {/* Form card */}
      <div className="px-5 pb-8">
        <div className="bg-navy-900 border border-navy-700 rounded-2xl p-6 shadow-xl max-w-md mx-auto">
          <h2 className="text-lg font-semibold text-white mb-6">Sign in</h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-silver-400 mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="captain@vessel.com"
                required
                className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white placeholder:text-silver-500 focus:outline-none focus:border-turquoise-500 focus:ring-1 focus:ring-turquoise-500/50"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-silver-400 mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-3 rounded-xl bg-navy-800 border border-navy-600 text-white placeholder:text-silver-500 focus:outline-none focus:border-turquoise-500 focus:ring-1 focus:ring-turquoise-500/50"
              />
            </div>

            {error && (
              <p className="text-sm text-status-red bg-status-red/10 border border-status-red/20 rounded-lg px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-turquoise-500 hover:bg-turquoise-400 active:bg-turquoise-600 text-navy-950 font-semibold text-sm tracking-wide transition-colors disabled:opacity-60"
            >
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <div className="mt-5 flex items-center gap-3">
            <div className="flex-1 h-px bg-navy-700" />
            <span className="text-xs text-silver-500">or</span>
            <div className="flex-1 h-px bg-navy-700" />
          </div>

          <button
            onClick={handleDemo}
            className="mt-5 w-full py-3.5 rounded-xl border border-turquoise-500/40 text-turquoise-400 font-medium text-sm hover:bg-turquoise-500/10 active:bg-turquoise-500/20 transition-colors"
          >
            Continue with Demo Account
          </button>

          <p className="mt-6 text-center text-xs text-silver-500">
            No account?{' '}
            <Link to="/register" className="text-turquoise-400 hover:underline">
              Register
            </Link>
          </p>
        </div>

        <p className="mt-6 text-center text-[10px] text-silver-600 max-w-xs mx-auto leading-relaxed">
          Prototype build · Fictional data only · Not for clinical use
        </p>
      </div>
    </div>
  );
}
