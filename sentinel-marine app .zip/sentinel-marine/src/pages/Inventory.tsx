import { Package } from 'lucide-react';
import { useAppData } from '../lib/AppDataContext';
import clsx from 'clsx';
import { format, parseISO, isValid } from 'date-fns';

export default function Inventory() {
  const { selectedVesselId, vessels, getInventoryForVessel } = useAppData();
  const vessel = vessels.find((v) => v.id === selectedVesselId) ?? vessels[0];
  const items = vessel ? getInventoryForVessel(vessel.id) : [];

  const statusLabel = { green: 'Good', amber: 'Attention', red: 'Action required' };
  const statusColor = {
    green: 'bg-status-green',
    amber: 'bg-status-amber',
    red: 'bg-status-red',
  };

  const red = items.filter((i) => i.status === 'red').length;
  const amber = items.filter((i) => i.status === 'amber').length;
  const green = items.filter((i) => i.status === 'green').length;

  return (
    <div className="px-4 pt-4 pb-6 max-w-lg mx-auto">
      <h1 className="text-xl font-semibold text-white mb-1">Medical Inventory</h1>
      <p className="text-sm text-silver-400 mb-4">{vessel?.name || 'No vessel'}</p>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-2 mb-5">
        <div className="bg-navy-800 border border-navy-700 rounded-xl p-3 text-center">
          <div className="text-lg font-bold text-status-green">{green}</div>
          <div className="text-[10px] text-silver-400 uppercase">Good</div>
        </div>
        <div className="bg-navy-800 border border-navy-700 rounded-xl p-3 text-center">
          <div className="text-lg font-bold text-status-amber">{amber}</div>
          <div className="text-[10px] text-silver-400 uppercase">Attention</div>
        </div>
        <div className="bg-navy-800 border border-navy-700 rounded-xl p-3 text-center">
          <div className="text-lg font-bold text-status-red">{red}</div>
          <div className="text-[10px] text-silver-400 uppercase">Action</div>
        </div>
      </div>

      <div className="space-y-2">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex items-start gap-3 p-3 rounded-xl bg-navy-800 border border-navy-700"
          >
            <span className={clsx('w-2.5 h-2.5 rounded-full mt-1.5 shrink-0', statusColor[item.status])} />
            <div className="flex-1 min-w-0">
              <div className="font-medium text-white text-sm">{item.name}</div>
              <div className="text-xs text-silver-400 mt-0.5">
                Qty: {item.quantity} · Min: {item.minQuantity} · {item.storageLocation}
              </div>
              {item.expiryDate && isValid(parseISO(item.expiryDate)) && (
                <div className="text-xs text-silver-500 mt-0.5">
                  Exp: {format(parseISO(item.expiryDate), 'dd MMM yyyy')}
                </div>
              )}
            </div>
            <span className="text-[10px] text-silver-500 uppercase shrink-0">{statusLabel[item.status]}</span>
          </div>
        ))}
      </div>

      {items.length === 0 && (
        <p className="text-silver-500 text-sm py-8 text-center">No inventory items</p>
      )}
    </div>
  );
}
