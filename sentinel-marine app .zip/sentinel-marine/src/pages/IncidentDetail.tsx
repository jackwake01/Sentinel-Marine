import { useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import {
  ChevronLeft, Activity, Pill, ClipboardList, FileText, Plus, Clock, User,
} from 'lucide-react';
import { useAppData } from '../lib/AppDataContext';
import { useAuth } from '../lib/AuthContext';
import { format } from 'date-fns';
import clsx from 'clsx';

export default function IncidentDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { incidents, crew, vessels, updateIncident, addObservation, addMedication, addTimelineEntry, closeIncident } = useAppData();

  const incident = incidents.find((i) => i.id === id);
  const patient = crew.find((c) => c.id === incident?.patientId);
  const vessel = vessels.find((v) => v.id === incident?.vesselId);

  const [tab, setTab] = useState<'timeline' | 'obs' | 'meds' | 'notes'>('timeline');
  const [showObsForm, setShowObsForm] = useState(false);
  const [showMedForm, setShowMedForm] = useState(false);

  // Observation form state
  const [obs, setObs] = useState({
    heartRate: '', systolicBP: '', diastolicBP: '', respiratoryRate: '',
    oxygenSaturation: '', temperature: '', gcs: '', bloodGlucose: '', painScore: '', consciousness: '',
  });

  // Medication form state
  const [med, setMed] = useState({
    medicationName: '', dose: '', route: 'Oral', reason: '', notes: '',
  });

  if (!incident) {
    return (
      <div className="p-6 text-center">
        <p className="text-silver-400">Incident not found</p>
        <button onClick={() => navigate('/')} className="mt-4 text-turquoise-400">Back to dashboard</button>
      </div>
    );
  }

  // Apply initial details from navigation state if present
  const navState = location.state as { mechanism?: string; nature?: string; condition?: string } | null;
  if (navState && (navState.mechanism || navState.nature || navState.condition) && !incident.mechanismOfInjury && !incident.natureOfIllness) {
    updateIncident(incident.id, {
      mechanismOfInjury: navState.mechanism || undefined,
      natureOfIllness: navState.nature || undefined,
      initialCondition: navState.condition || undefined,
    });
    if (navState.mechanism || navState.nature) {
      addTimelineEntry(incident.id, {
        timestamp: new Date().toISOString(),
        type: 'assessment',
        description: `Initial assessment: ${[navState.mechanism, navState.nature].filter(Boolean).join(' / ')}`,
        recordedBy: user?.fullName || 'Unknown',
      });
    }
  }

  const handleAddObs = () => {
    if (!user) return;
    const now = new Date().toISOString();
    addObservation(incident.id, {
      timestamp: now,
      heartRate: obs.heartRate ? Number(obs.heartRate) : undefined,
      systolicBP: obs.systolicBP ? Number(obs.systolicBP) : undefined,
      diastolicBP: obs.diastolicBP ? Number(obs.diastolicBP) : undefined,
      respiratoryRate: obs.respiratoryRate ? Number(obs.respiratoryRate) : undefined,
      oxygenSaturation: obs.oxygenSaturation ? Number(obs.oxygenSaturation) : undefined,
      temperature: obs.temperature ? Number(obs.temperature) : undefined,
      gcs: obs.gcs ? Number(obs.gcs) : undefined,
      bloodGlucose: obs.bloodGlucose ? Number(obs.bloodGlucose) : undefined,
      painScore: obs.painScore ? Number(obs.painScore) : undefined,
      consciousness: obs.consciousness || undefined,
      recordedBy: user.fullName,
    });
    setObs({ heartRate: '', systolicBP: '', diastolicBP: '', respiratoryRate: '', oxygenSaturation: '', temperature: '', gcs: '', bloodGlucose: '', painScore: '', consciousness: '' });
    setShowObsForm(false);
    setTab('timeline');
  };

  const handleAddMed = () => {
    if (!user || !med.medicationName) return;
    const now = new Date().toISOString();
    addMedication(incident.id, {
      timestamp: now,
      medicationName: med.medicationName,
      dose: med.dose,
      route: med.route,
      administeredBy: user.fullName,
      reason: med.reason,
      notes: med.notes || undefined,
    });
    setMed({ medicationName: '', dose: '', route: 'Oral', reason: '', notes: '' });
    setShowMedForm(false);
    setTab('timeline');
  };

  const tabs = [
    { id: 'timeline' as const, label: 'Timeline', icon: Clock },
    { id: 'obs' as const, label: 'Obs', icon: Activity },
    { id: 'meds' as const, label: 'Meds', icon: Pill },
    { id: 'notes' as const, label: 'Notes', icon: ClipboardList },
  ];

  return (
    <div className="min-h-dvh bg-navy-900 flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-navy-950 border-b border-navy-700">
        <div className="px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 -ml-2 rounded-lg hover:bg-navy-800">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-white truncate">{incident.patientName}</div>
            <div className="text-xs text-silver-400">
              {format(new Date(incident.startTime), 'dd MMM · HH:mm')} · {vessel?.name}
              {incident.status === 'active' && (
                <span className="ml-2 text-status-amber">● Active</span>
              )}
            </div>
          </div>
        </div>

        {/* Allergy banner */}
        {patient && patient.allergies.length > 0 && (
          <div className="px-4 py-2 bg-status-amber/15 border-t border-status-amber/30 text-sm text-status-amber font-medium">
            ⚠ ALLERGIES: {patient.allergies.join(', ')}
          </div>
        )}

        {/* Tabs */}
        <div className="flex border-t border-navy-700">
          {tabs.map(({ id: tid, label, icon: Icon }) => (
            <button
              key={tid}
              onClick={() => setTab(tid)}
              className={clsx(
                'flex-1 flex flex-col items-center gap-0.5 py-2.5 text-xs font-medium transition-colors',
                tab === tid ? 'text-turquoise-400 border-b-2 border-turquoise-400' : 'text-silver-400'
              )}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 pb-32 max-w-lg mx-auto w-full">
        {tab === 'timeline' && (
          <div className="space-y-0">
            {incident.timeline.length === 0 ? (
              <p className="text-silver-500 text-sm py-4">No timeline entries yet</p>
            ) : (
              incident.timeline.map((entry, idx) => (
                <div key={entry.id} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={clsx(
                      'w-2.5 h-2.5 rounded-full mt-1.5 shrink-0',
                      entry.type === 'created' ? 'bg-turquoise-400' :
                      entry.type === 'observation' ? 'bg-blue-400' :
                      entry.type === 'medication' ? 'bg-purple-400' :
                      entry.type === 'handover' ? 'bg-status-green' : 'bg-silver-400'
                    )} />
                    {idx < incident.timeline.length - 1 && <div className="w-px flex-1 bg-navy-700 my-1" />}
                  </div>
                  <div className="pb-4 min-w-0">
                    <div className="text-xs text-silver-500 font-mono">
                      {format(new Date(entry.timestamp), 'HH:mm:ss')}
                    </div>
                    <div className="text-sm text-white mt-0.5">{entry.description}</div>
                    <div className="text-xs text-silver-500 mt-0.5">{entry.recordedBy}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {tab === 'obs' && (
          <div>
            {incident.observations.length === 0 ? (
              <p className="text-silver-500 text-sm py-4">No observations recorded</p>
            ) : (
              <div className="space-y-3">
                {[...incident.observations].reverse().map((o) => (
                  <div key={o.id} className="bg-navy-800 border border-navy-700 rounded-xl p-3">
                    <div className="text-xs text-silver-500 font-mono mb-2">
                      {format(new Date(o.timestamp), 'HH:mm:ss')} · {o.recordedBy}
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      {o.heartRate != null && <div><span className="text-silver-500">HR</span> <span className="text-white font-medium">{o.heartRate}</span></div>}
                      {o.systolicBP != null && <div><span className="text-silver-500">BP</span> <span className="text-white font-medium">{o.systolicBP}/{o.diastolicBP}</span></div>}
                      {o.respiratoryRate != null && <div><span className="text-silver-500">RR</span> <span className="text-white font-medium">{o.respiratoryRate}</span></div>}
                      {o.oxygenSaturation != null && <div><span className="text-silver-500">SpO₂</span> <span className="text-white font-medium">{o.oxygenSaturation}%</span></div>}
                      {o.temperature != null && <div><span className="text-silver-500">Temp</span> <span className="text-white font-medium">{o.temperature}°</span></div>}
                      {o.gcs != null && <div><span className="text-silver-500">GCS</span> <span className="text-white font-medium">{o.gcs}</span></div>}
                      {o.painScore != null && <div><span className="text-silver-500">Pain</span> <span className="text-white font-medium">{o.painScore}/10</span></div>}
                      {o.bloodGlucose != null && <div><span className="text-silver-500">BGL</span> <span className="text-white font-medium">{o.bloodGlucose}</span></div>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'meds' && (
          <div>
            {incident.medications.length === 0 ? (
              <p className="text-silver-500 text-sm py-4">No medications administered</p>
            ) : (
              <div className="space-y-3">
                {incident.medications.map((m) => (
                  <div key={m.id} className="bg-navy-800 border border-navy-700 rounded-xl p-3">
                    <div className="text-xs text-silver-500 font-mono mb-1">
                      {format(new Date(m.timestamp), 'HH:mm:ss')}
                    </div>
                    <div className="font-medium text-white">{m.medicationName} — {m.dose}</div>
                    <div className="text-sm text-silver-400">{m.route} · {m.administeredBy}</div>
                    {m.reason && <div className="text-xs text-silver-500 mt-1">Reason: {m.reason}</div>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'notes' && (
          <div className="space-y-3 text-sm">
            <div className="bg-navy-800 border border-navy-700 rounded-xl p-4">
              <div className="text-xs text-silver-500 mb-1">Location</div>
              <div className="text-white">{incident.location || '—'}</div>
            </div>
            <div className="bg-navy-800 border border-navy-700 rounded-xl p-4">
              <div className="text-xs text-silver-500 mb-1">Mechanism of injury</div>
              <div className="text-white">{incident.mechanismOfInjury || 'Not recorded'}</div>
            </div>
            <div className="bg-navy-800 border border-navy-700 rounded-xl p-4">
              <div className="text-xs text-silver-500 mb-1">Nature of illness</div>
              <div className="text-white">{incident.natureOfIllness || 'Not recorded'}</div>
            </div>
            <div className="bg-navy-800 border border-navy-700 rounded-xl p-4">
              <div className="text-xs text-silver-500 mb-1">Initial condition</div>
              <div className="text-white">{incident.initialCondition || 'Not recorded'}</div>
            </div>
            {patient && (
              <div className="bg-navy-800 border border-navy-700 rounded-xl p-4">
                <div className="text-xs text-silver-500 mb-1">Patient medical background</div>
                <div className="text-white text-sm space-y-1">
                  <div>Allergies: {patient.allergies.join(', ') || 'None known'}</div>
                  <div>Conditions: {patient.medicalConditions.join(', ') || 'None'}</div>
                  <div>Meds: {patient.currentMedications.join(', ') || 'None'}</div>
                  <div>Blood group: {patient.bloodGroup || 'Unknown'}</div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Action bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-navy-950/95 backdrop-blur border-t border-navy-700 p-3 safe-bottom">
        <div className="max-w-lg mx-auto flex gap-2">
          <button
            onClick={() => setShowObsForm(true)}
            className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl bg-navy-800 border border-navy-600 text-sm font-medium text-white"
          >
            <Activity className="w-4 h-4" /> Obs
          </button>
          <button
            onClick={() => setShowMedForm(true)}
            className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl bg-navy-800 border border-navy-600 text-sm font-medium text-white"
          >
            <Pill className="w-4 h-4" /> Med
          </button>
          <button
            onClick={() => navigate(`/incident/${incident.id}/handover`)}
            className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl bg-turquoise-500 text-navy-950 text-sm font-semibold"
          >
            <FileText className="w-4 h-4" /> Handover
          </button>
        </div>
      </div>

      {/* Observation form modal */}
      {showObsForm && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowObsForm(false)} />
          <div className="relative w-full max-w-lg max-h-[85dvh] overflow-y-auto bg-navy-900 border-t border-navy-700 rounded-t-2xl p-5">
            <h3 className="text-lg font-semibold mb-4">Record observations</h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                { key: 'heartRate', label: 'Heart rate', unit: 'bpm' },
                { key: 'systolicBP', label: 'Systolic BP', unit: 'mmHg' },
                { key: 'diastolicBP', label: 'Diastolic BP', unit: 'mmHg' },
                { key: 'respiratoryRate', label: 'Resp. rate', unit: '/min' },
                { key: 'oxygenSaturation', label: 'SpO₂', unit: '%' },
                { key: 'temperature', label: 'Temperature', unit: '°C' },
                { key: 'gcs', label: 'GCS', unit: '' },
                { key: 'painScore', label: 'Pain score', unit: '/10' },
                { key: 'bloodGlucose', label: 'Blood glucose', unit: 'mmol/L' },
              ].map(({ key, label, unit }) => (
                <div key={key}>
                  <label className="block text-xs text-silver-400 mb-1">{label}</label>
                  <div className="relative">
                    <input
                      type="number"
                      inputMode="decimal"
                      value={(obs as any)[key]}
                      onChange={(e) => setObs({ ...obs, [key]: e.target.value })}
                      className="w-full px-3 py-2.5 rounded-xl bg-navy-800 border border-navy-600 text-white text-sm focus:outline-none focus:border-turquoise-500"
                    />
                    {unit && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-silver-500">{unit}</span>}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <label className="block text-xs text-silver-400 mb-1">Consciousness</label>
              <select
                value={obs.consciousness}
                onChange={(e) => setObs({ ...obs, consciousness: e.target.value })}
                className="w-full px-3 py-2.5 rounded-xl bg-navy-800 border border-navy-600 text-white text-sm focus:outline-none focus:border-turquoise-500"
              >
                <option value="">—</option>
                <option value="Alert">Alert</option>
                <option value="Voice">Voice</option>
                <option value="Pain">Pain</option>
                <option value="Unresponsive">Unresponsive</option>
              </select>
            </div>
            <button
              onClick={handleAddObs}
              className="w-full mt-5 py-3.5 rounded-xl bg-turquoise-500 text-navy-950 font-semibold"
            >
              Save observations
            </button>
          </div>
        </div>
      )}

      {/* Medication form modal */}
      {showMedForm && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowMedForm(false)} />
          <div className="relative w-full max-w-lg max-h-[85dvh] overflow-y-auto bg-navy-900 border-t border-navy-700 rounded-t-2xl p-5">
            <h3 className="text-lg font-semibold mb-4">Record medication</h3>
            {patient && patient.allergies.length > 0 && (
              <div className="mb-4 p-3 rounded-xl bg-status-amber/15 border border-status-amber/40 text-sm text-status-amber font-medium">
                ⚠ Patient allergies: {patient.allergies.join(', ')}
              </div>
            )}
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-silver-400 mb-1">Medication name</label>
                <input
                  value={med.medicationName}
                  onChange={(e) => setMed({ ...med, medicationName: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-xl bg-navy-800 border border-navy-600 text-white text-sm focus:outline-none focus:border-turquoise-500"
                  placeholder="e.g. Paracetamol"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-silver-400 mb-1">Dose</label>
                  <input
                    value={med.dose}
                    onChange={(e) => setMed({ ...med, dose: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-navy-800 border border-navy-600 text-white text-sm focus:outline-none focus:border-turquoise-500"
                    placeholder="1g"
                  />
                </div>
                <div>
                  <label className="block text-xs text-silver-400 mb-1">Route</label>
                  <select
                    value={med.route}
                    onChange={(e) => setMed({ ...med, route: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-navy-800 border border-navy-600 text-white text-sm focus:outline-none focus:border-turquoise-500"
                  >
                    <option>Oral</option>
                    <option>IV</option>
                    <option>IM</option>
                    <option>SC</option>
                    <option>Inhaled</option>
                    <option>Topical</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs text-silver-400 mb-1">Reason</label>
                <input
                  value={med.reason}
                  onChange={(e) => setMed({ ...med, reason: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-xl bg-navy-800 border border-navy-600 text-white text-sm focus:outline-none focus:border-turquoise-500"
                  placeholder="Pain relief"
                />
              </div>
            </div>
            <button
              onClick={handleAddMed}
              className="w-full mt-5 py-3.5 rounded-xl bg-turquoise-500 text-navy-950 font-semibold"
            >
              Record administration
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
