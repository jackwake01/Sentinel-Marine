import { useNavigate } from 'react-router-dom';
import { FileText, ChevronRight } from 'lucide-react';
import { useAppData } from '../lib/AppDataContext';
import { format } from 'date-fns';
import clsx from 'clsx';

export default function Incidents() {
  const navigate = useNavigate();
  const { selectedVesselId, vessels, getIncidentsForVessel } = useAppData();
  const vessel = vessels.find((v) => v.id === selectedVesselId) ?? vessels[0];
  const incidents = vessel ? getIncidentsForVessel(vessel.id) : [];

  return (
    <div className="px-4 pt-4 pb-6 max-w-lg mx-auto">
      <h1 className="text-xl font-semibold text-white mb-1">Incident History</h1>
      <p className="text-sm text-silver-400 mb-5">{vessel?.name || 'No vessel'}</p>

      <div className="space-y-2">
        {incidents.map((inc) => (
          <button
            key={inc.id}
            onClick={() => navigate(`/incident/${inc.id}`)}
            className="w-full flex items-center gap-3 p-4 rounded-xl bg-navy-800 border border-navy-700 text-left hover:border-navy-600"
          >
            <div className="w-10 h-10 rounded-xl bg-navy-700 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5 text-turquoise-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-white truncate">{inc.patientName}</div>
              <div className="text-xs text-silver-400">
                {format(new Date(inc.startTime), 'dd MMM yyyy · HH:mm')}
              </div>
              <div className="text-xs text-silver-500 mt-0.5 truncate">
                {inc.mechanismOfInjury || inc.natureOfIllness || inc.location}
              </div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <span
                className={clsx(
                  'text-[10px] uppercase font-medium px-2 py-0.5 rounded-full',
                  inc.status === 'active'
                    ? 'bg-status-amber/20 text-status-amber'
                    : 'bg-navy-700 text-silver-400'
                )}
              >
                {inc.status}
              </span>
              <ChevronRight className="w-4 h-4 text-silver-500" />
            </div>
          </button>
        ))}
      </div>

      {incidents.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-10 h-10 text-navy-600 mx-auto mb-3" />
          <p className="text-silver-500 text-sm">No incidents recorded</p>
          <button
            onClick={() => navigate('/incident/new')}
            className="mt-4 px-5 py-2.5 rounded-xl bg-status-red text-white text-sm font-semibold"
          >
            Start Medical Incident
          </button>
        </div>
      )}
    </div>
  );
}
